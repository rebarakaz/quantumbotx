# Strategi trading
