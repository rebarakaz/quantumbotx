# Modul utilitas
